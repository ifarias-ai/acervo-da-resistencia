const images=[
["Entre nós","Imagem 01","Uma imagem fictícia para representar a coleção.","https://picsum.photos/id/1011/1800/1400"],
["Movimento","Imagem 02","Uma composição visual simples para testar a galeria.","https://picsum.photos/id/1015/1800/1400"],
["Paisagem","Imagem 03","Conteúdo demonstrativo. Depois podemos substituir pelas suas imagens.","https://picsum.photos/id/1016/1800/1400"],
["Encontro","Imagem 04","O texto de cada imagem aparece junto da imagem ampliada.","https://picsum.photos/id/1025/1800/1400"],
["Caminho","Imagem 05","A interface foi pensada para deixar a imagem em primeiro plano.","https://picsum.photos/id/1035/1800/1400"],
["Horizonte","Imagem 06","Podemos alterar tipografia, cores e proporções depois.","https://picsum.photos/id/1039/1800/1400"],
["Presença","Imagem 07","Este espaço pode receber descrição, crédito ou mensagem.","https://picsum.photos/id/1040/1800/1400"],
["Juntos","Imagem 08","Versão fictícia para visualizar o funcionamento do site.","https://picsum.photos/id/1043/1800/1400"],
["Detalhe","Imagem 09","Mais uma imagem demonstrativa da coleção.","https://picsum.photos/id/1050/1800/1400"],
["Luz","Imagem 10","Podemos criar categorias e filtros futuramente.","https://picsum.photos/id/1057/1800/1400"],
["Vínculo","Imagem 11","A página continua sendo uma única página.","https://picsum.photos/id/1062/1800/1400"],
["Ação","Imagem 12","Baixar e compartilhar ficam junto da imagem.","https://picsum.photos/id/1067/1800/1400"]
];

const gallery=document.querySelector("#gallery"),viewer=document.querySelector("#viewer");
const img=document.querySelector("#viewerImg"),title=document.querySelector("#viewerTitle"),tag=document.querySelector("#viewerTag"),text=document.querySelector("#viewerText");
const download=document.querySelector("#download"),share=document.querySelector("#share"),count=document.querySelector("#downloadCount");
let current=0;

images.forEach((item,i)=>{
 const b=document.createElement("button"); b.className="card"; b.setAttribute("aria-label","Abrir "+item[0]);
 b.innerHTML=`<img src="${item[3]}" alt="${item[0]}" loading="lazy">`;
 b.onclick=()=>open(i); gallery.appendChild(b);
});

function open(i){
 current=(i+images.length)%images.length;
 const x=images[current];
 img.src=x[3];img.alt=x[0];title.textContent=x[0];tag.textContent=x[1];text.textContent=x[2];
 download.href=x[3];download.download=x[0].toLowerCase().replaceAll(" ","-")+".jpg";
 viewer.classList.add("open");viewer.setAttribute("aria-hidden","false");document.body.classList.add("lock");
}
function close(){viewer.classList.remove("open");viewer.setAttribute("aria-hidden","true");document.body.classList.remove("lock")}
function move(n){open(current+n)}
document.querySelector("#close").onclick=close;
document.querySelector("#prev").onclick=()=>move(-1);
document.querySelector("#next").onclick=()=>move(1);
viewer.addEventListener("click",e=>{if(e.target===viewer)close()});
document.addEventListener("keydown",e=>{
 if(!viewer.classList.contains("open"))return;
 if(e.key==="Escape")close(); if(e.key==="ArrowLeft")move(-1); if(e.key==="ArrowRight")move(1);
});
download.onclick=()=>{count.textContent=(Number(count.textContent.replace(".",""))+1).toLocaleString("pt-BR")};
share.onclick=async()=>{
 const data={title:title.textContent,text:text.textContent,url:location.href};
 try{
   if(navigator.share) await navigator.share(data);
   else {await navigator.clipboard.writeText(location.href);share.textContent="Link copiado!";setTimeout(()=>share.textContent="Compartilhar",1500)}
 }catch{}
};
let startX=0,startY=0;
viewer.addEventListener("touchstart",e=>{startX=e.changedTouches[0].screenX;startY=e.changedTouches[0].screenY},{passive:true});
viewer.addEventListener("touchend",e=>{
 const dx=e.changedTouches[0].screenX-startX,dy=e.changedTouches[0].screenY-startY;
 if(Math.abs(dx)>55 && Math.abs(dx)>Math.abs(dy)) move(dx<0?1:-1);
},{passive:true});
